function mostrarMetodo(metodo) {
  let contenido = document.getElementById("contenido");

  if (metodo === "error_absoluto") {
    contenido.innerHTML = `
      <h2>Error Absoluto</h2>
      <p>El error absoluto mide la diferencia entre el valor real y el valor aproximado.</p>
      <form>
        Valor real: <input type="number" id="real" value="3.1416"><br>
        Valor aproximado: <input type="number" id="aprox" value="3.14"><br>
        <button type="button" onclick="calcularErrorAbsoluto()">Calcular</button>
      </form>
      <div id="resultado"></div>
      <div id="grafica"></div>
    `;
  }

  if (metodo === "error_relativo") {
    contenido.innerHTML = `
      <h2>Error Relativo</h2>
      <p>El error relativo compara el error absoluto con el valor real.</p>
      <form>
        Valor real: <input type="number" id="real" value="3.1416"><br>
        Valor aproximado: <input type="number" id="aprox" value="3.14"><br>
        <button type="button" onclick="calcularErrorRelativo()">Calcular</button>
      </form>
      <div id="resultado"></div>
      <div id="grafica"></div>
    `;
  }

  if (metodo === "error_porcentual") {
    contenido.innerHTML = `
      <h2>Error Porcentual</h2>
      <p>El error porcentual expresa el error relativo en porcentaje.</p>
      <form>
        Valor real: <input type="number" id="real" value="3.1416"><br>
        Valor aproximado: <input type="number" id="aprox" value="3.14"><br>
        <button type="button" onclick="calcularErrorPorcentual()">Calcular</button>
      </form>
      <div id="resultado"></div>
      <div id="grafica"></div>
    `;
  }

  if (metodo === "redondeo") {
    contenido.innerHTML = `
      <h2>Errores de Redondeo</h2>
      <p>El error de redondeo ocurre al ajustar un número a menos decimales.</p>
      <form>
        Valor real: <input type="number" id="real" value="3.1416" step="0.0001"><br>
        Decimales: <input type="number" id="dec" value="2"><br>
        <button type="button" onclick="calcularRedondeo()">Calcular</button>
      </form>
      <div id="resultado"></div>
      <div id="grafica"></div>
    `;
  }

  if (metodo === "truncamiento") {
    contenido.innerHTML = `
      <h2>Errores de Truncamiento</h2>
      <p>El error de truncamiento ocurre al cortar decimales sin redondear.</p>
      <form>
        Valor real: <input type="number" id="real" value="3.1416" step="0.0001"><br>
        Decimales: <input type="number" id="dec" value="2"><br>
        <button type="button" onclick="calcularTruncamiento()">Calcular</button>
      </form>
      <div id="resultado"></div>
      <div id="grafica"></div>
    `;
  }
}

// FUNCIONES DE CÁLCULO
function calcularErrorAbsoluto() {
  let real = parseFloat(document.getElementById("real").value);
  let aprox = parseFloat(document.getElementById("aprox").value);
  let error = Math.abs(real - aprox);

  let tabla = `<table>
    <tr><th>Valor Real</th><th>Valor Aproximado</th><th>Error Absoluto</th></tr>
    <tr><td>${real}</td><td>${aprox}</td><td>${error}</td></tr>
  </table>`;
  document.getElementById("resultado").innerHTML = tabla;

  Plotly.newPlot("grafica", [{x:["Real","Aproximado"], y:[real, aprox], type:"bar"}]);
}

function calcularErrorRelativo() {
  let real = parseFloat(document.getElementById("real").value);
  let aprox = parseFloat(document.getElementById("aprox").value);
  let errorAbs = Math.abs(real - aprox);
  let errorRel = errorAbs / real;

  let tabla = `<table>
    <tr><th>Error Absoluto</th><th>Error Relativo</th></tr>
    <tr><td>${errorAbs}</td><td>${errorRel}</td></tr>
  </table>`;
  document.getElementById("resultado").innerHTML = tabla;

  Plotly.newPlot("grafica", [{x:["Error Absoluto","Error Relativo"], y:[errorAbs, errorRel], type:"bar"}]);
}

function calcularErrorPorcentual() {
  let real = parseFloat(document.getElementById("real").value);
  let aprox = parseFloat(document.getElementById("aprox").value);
  let errorAbs = Math.abs(real - aprox);
  let errorRel = errorAbs / real;
  let errorPorc = errorRel * 100;

  let tabla = `<table>
    <tr><th>Error Relativo</th><th>Error Porcentual (%)</th></tr>
    <tr><td>${errorRel}</td><td>${errorPorc}</td></tr>
  </table>`;
  document.getElementById("resultado").innerHTML = tabla;

  Plotly.newPlot("grafica", [{x:["Error Relativo","Error Porcentual"], y:[errorRel, errorPorc], type:"bar"}]);
}

function calcularRedondeo() {
  let real = parseFloat(document.getElementById("real").value);
  let dec = parseInt(document.getElementById("dec").value);
  let redondeado = parseFloat(real.toFixed(dec));
  let error = Math.abs(real - redondeado);

  let tabla = `<table>
    <tr><th>Valor Real</th><th>Redondeado</th><th>Error</th></tr>
    <tr><td>${real}</td><td>${redondeado}</td><td>${error}</td></tr>
  </table>`;
  document.getElementById("resultado").innerHTML = tabla;

  Plotly.newPlot("grafica", [{x:["Real","Redondeado"], y:[real, redondeado], type:"bar"}]);
}

function calcularTruncamiento() {
  let real = document.getElementById("real").value;
  let dec = parseInt(document.getElementById("dec").value);
  let truncado = real.substring(0, real.indexOf(".") + dec + 1);
  let truncadoNum = parseFloat(truncado);
  let error = Math.abs(parseFloat(real) - truncadoNum);

  let tabla = `<table>
    <tr><th>Valor Real</th><th>Truncado</th><th>Error</th></tr>
    <tr><td>${real}</td><td>${truncadoNum}</td><td>${error}</td></tr>
  </table>`;
  document.getElementById("resultado").innerHTML = tabla;

  Plotly.newPlot("grafica", [{x:["Real","Truncado"], y:[parseFloat(real), truncadoNum], type:"bar"}]);
}
